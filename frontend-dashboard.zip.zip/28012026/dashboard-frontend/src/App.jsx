import "./App.css";

function CourseCard({ title, duration, level }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      <p><b>Duration:</b> {duration}</p>
      <p><b>Level:</b> {level}</p>
    </div>
  );
}

function App() {
  return (
    <div className="app">
      <div className="header">📚 Learning Dashboard</div>

      <div className="welcome">
        <h1>Welcome Back 👋</h1>
        <p>Keep learning and level up your skills!</p>
      </div>

      <div className="card-container">
        <CourseCard title="React Basics" duration="4 Weeks" level="Beginner" />
        <CourseCard title="JavaScript Advanced" duration="6 Weeks" level="Intermediate" />
        <CourseCard title="Python for AI" duration="8 Weeks" level="Advanced" />
      </div>
    </div>
  );
}

export default App;
