const mongoose = require("mongoose");

const lendSchema = new mongoose.Schema({
    bookTitle: {
        type: String,
        required: true
    },
    borrowerName: {
        type: String,
        required: true
    },
    dueDate: {
        type: Date,
        required: true
    }
}, { timestamps: true });

module.exports = mongoose.model("Lend", lendSchema);