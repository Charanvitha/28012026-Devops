const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

// ---------- Middleware ----------
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// allows browser to open lend.html
app.use(express.static("public"));


// ---------- MongoDB Connection ----------
mongoose.connect("mongodb+srv://bookuser:Book12345@cluster0.zzlts3r.mongodb.net/bookDB?retryWrites=true&w=majority")
.then(() => {
    console.log("MongoDB Connected");
})
.catch((err) => {
    console.log("MongoDB Connection Error:", err);
});


// ---------- Routes ----------
const lendRoutes = require("./routes/lendRoutes");
app.use("/lend", lendRoutes);


// ---------- Home Route (optional) ----------
app.get("/", (req, res) => {
    res.send("Book Lending API is running...");
});


// ---------- Start Server ----------
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});