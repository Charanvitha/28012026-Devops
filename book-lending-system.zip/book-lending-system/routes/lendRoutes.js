const express = require("express");
const router = express.Router();

// VERY IMPORTANT: capital L
const Lend = require("../models/lend");


// ---------------- POST /lend ----------------
// Lend a book
router.post("/", async (req, res) => {
    try {
        const lend = new Lend({
            bookTitle: req.body.bookTitle,
            borrowerName: req.body.borrowerName,
            dueDate: req.body.dueDate
        });

        await lend.save();
        res.send("Book Lent Successfully!");
    } catch (err) {
        res.status(500).send(err.message);
    }
});


// ---------------- GET /lend ----------------
// Retrieve all records
router.get("/", async (req, res) => {
    try {
        const records = await Lend.find();
        res.json(records);
    } catch (err) {
        res.status(500).send(err.message);
    }
});


// ---------------- PUT /lend/:id ----------------
// Update record
router.put("/:id", async (req, res) => {
    try {
        const updated = await Lend.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        res.json(updated);
    } catch (err) {
        res.status(500).send(err.message);
    }
});


// ---------------- DELETE /lend/:id ----------------
// Delete record
router.delete("/:id", async (req, res) => {
    try {
        await Lend.findByIdAndDelete(req.params.id);
        res.send("Record deleted");
    } catch (err) {
        res.status(500).send(err.message);
    }
});

module.exports = router;